//
//  Books+CoreDataClass.swift
//  
//
//  Created by jai prakash on 16/08/24.
//
//

import Foundation
import CoreData

@objc(Books)
public class Books: NSManagedObject {

}
