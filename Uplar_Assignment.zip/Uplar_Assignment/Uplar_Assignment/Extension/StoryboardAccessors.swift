//
//  StroyboardAccessors.swift
//  UplerAssignment
//
//  Created by jai prakash on 15/08/24.
//

import UIKit

class StoryboardAccessors: NSObject {
    
    static var main: UIStoryboard {
        return UIStoryboard(name: "Main", bundle: nil)
    }
}
