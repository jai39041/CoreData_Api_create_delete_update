//
//  ViewControllerAccessors.swift
//  UplerAssignment
//
//  Created by jai prakash on 15/08/24.
//

import Foundation
import UIKit

class ViewControllerAccessors {
    
    //MARK:- Auth Storyboard
    
    static var addBookVC: AddBookVC{
        if let viewController = StoryboardAccessors.main.instantiateViewController(withIdentifier: String(describing: AddBookVC.self)) as? AddBookVC {
            return viewController
        } else {
            return AddBookVC()
        }
    }
    
    
    static var bookDetailsVC: BookDetailsVC{
        if let viewController = StoryboardAccessors.main.instantiateViewController(withIdentifier: String(describing: BookDetailsVC.self)) as? BookDetailsVC {
            return viewController
        } else {
            return BookDetailsVC()
        }
    }
    
    
    static var bookListVC: BookListVC{
        if let viewController = StoryboardAccessors.main.instantiateViewController(withIdentifier: String(describing: BookListVC.self)) as? BookListVC {
            return viewController
        } else {
            return BookListVC()
        }
    }
    
  
    
}
    
   
