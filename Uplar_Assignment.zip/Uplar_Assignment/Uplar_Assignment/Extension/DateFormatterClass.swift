
import Foundation

func convertDateString(dateString: String) -> String? {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
    dateFormatter.timeZone
 = TimeZone(secondsFromGMT: 0) // Adjust time zone if needed

    if let date = dateFormatter.date(from: dateString) {
        dateFormatter.dateFormat = "dd-MM-yyyy"
        return dateFormatter.string(from: date)

    } else {
        return nil // Or handle the error as needed
    }
}


func convertDateFormat(inputDateString: String) -> String? {
    // Date formatter for the input date string
    let inputDateFormatter = DateFormatter()
    inputDateFormatter.dateFormat = "dd-MM-yyyy"
    
    // Date formatter for the output date string
    let outputDateFormatter = DateFormatter()
    outputDateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
    outputDateFormatter.timeZone = TimeZone(abbreviation: "UTC")
    
    // Convert the input date string to a Date object
    guard let date = inputDateFormatter.date(from: inputDateString) else {
        print("Error: Invalid date string format")
        return nil
    }
    
    // Convert the Date object to the desired output format
    let outputDateString = outputDateFormatter.string(from: date)
    return outputDateString
}


