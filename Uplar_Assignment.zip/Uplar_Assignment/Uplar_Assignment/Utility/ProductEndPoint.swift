//
//  ProductEndPoint.swift
//  UplerAssignment
//
//  Created by jai prakash on 15/08/24.
//

import Foundation

enum BookEndPoint {
    case books // Module - GET
    case bookDetails(id: Int)
}




// https://fakestoreapi.com/products
extension BookEndPoint: EndPointType {
  
    
    var path: String {
        switch self {
        case .books:
            return ""
        case .bookDetails:
            return ""
                
                
        }
    }

    var baseURL: String {
        switch self {
        case .books:
            return "https://my-json-server.typicode.com/cutamar/mock/books"
            case .bookDetails(let id):
            return "https://my-json-server.typicode.com/cutamar/mock/books/\(id)"
        }
    }

    var url: URL? {
        return URL(string: "\(baseURL)\(path)")
    }

    var method: HTTPMethods {
        switch self {
        case .books:
            return .get

        case .bookDetails(id: let id):
            return .get
        }
    }

    var body: Encodable? {
        switch self {
        case .books:
            return nil
            case .bookDetails(id: let id):
                return nil
        }
    }

    var headers: [String : String]? {
        APIManager.commonHeaders
    }
}
