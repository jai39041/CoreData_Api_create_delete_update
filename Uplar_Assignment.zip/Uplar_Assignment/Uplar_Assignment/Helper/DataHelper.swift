import Foundation
import CoreData
import UIKit

class DataHelper {
    static let shared = DataHelper()

    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext

    
    func saveBook(title: String, author: String, description: String, publicationDate: String, coverImage: UIImage?) {
          // Create a new instance of the Books entity
          let book = NSEntityDescription.insertNewObject(forEntityName: "Books", into: context!) as! Books

          // Set the properties of the book entity
          book.title = title
          book.author = author
          book.bookDescription = description
          book.publicationDate = publicationDate
          
          // Convert UIImage to Data and set to cover
          if let coverImage = coverImage {
//              book.cover = coverImage.jpegData(compressionQuality: 1.0)
          }

          // Attempt to save the context
          do {
              try context?.save()
              print("Book saved successfully")
              UIAlertAction(title: "Book saved successfully", style: .default)
          } catch {
              print("Failed to save book: \(error.localizedDescription)")
          }
      }
    
    
    
    
    
    
    
    // Function to save a single BookMC object
    func saveBook(book: BookMC) {
        guard let context = context else { return }

        let bookEntity = NSEntityDescription.insertNewObject(forEntityName: "Books", into: context) as! Books

        bookEntity.author = book.author
        bookEntity.bookDescription = book.description
        bookEntity.cover = book.cover
        
        if let id = book.id {
            bookEntity.id = Int64(id)
        }
        
        bookEntity.publicationDate = book.publicationDate
        bookEntity.title = book.title
        
        do {
            try context.save()
            print("Data saved successfully")
        } catch {
            print("Data not saved: \(error.localizedDescription)")
        }
    }

    // Function to save an array of BookMC objects
    func saveBooks(books: [BookMC]) {
        books.forEach { saveBook(book: $0) }
    }

    // Function to fetch all Books from Core Data
    func fetchBooks() -> [Books] {
        var books = [Books]()
        let fetchRequest = NSFetchRequest<Books>(entityName: "Books")
        
        do {
            books = try context?.fetch(fetchRequest) ?? []
        } catch {
            print("Failed to fetch data: \(error.localizedDescription)")
        }
        
        return books
    }

    // Function to delete a specific Book from Core Data
    
    func deleteBook(at index: Int) {
        var books = fetchBooks()

        if index < books.count {
            context?.delete(books[index])
            books.remove(at: index)

            do {
                try context?.save()
            } catch {
                print("Data not deleted: \(error.localizedDescription)")
            }
        }
    }
    
    
    func updateBook(book: BookMC) {
        let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
            let fetchRequest: NSFetchRequest<Books> = Books.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %d", book.id!)
            
            do {
                let results = try context!.fetch(fetchRequest)
                if let existingBook = results.first {
                    // Update the existing book's properties
                    existingBook.title = book.title
                    existingBook.author = book.author
                    existingBook.bookDescription = book.description
                    existingBook.publicationDate = book.publicationDate
                    // Update other properties as needed
                    
                    try context!.save()
                }
            } catch {
                print("Failed to update book: \(error)")
            }
        }
    
    

}

extension DataHelper {
    func clearAllBooks() {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Books")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        
        do {
            try context?.execute(deleteRequest)
            try context?.save()
        } catch {
            print("Failed to delete records: \(error.localizedDescription)")
        }
    }
}
