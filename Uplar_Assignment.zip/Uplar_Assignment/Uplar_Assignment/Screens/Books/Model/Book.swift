//
//  Book.swift
//  UplerAssignment
//
//  Created by jai prakash on 15/08/24.
//

import Foundation

// MARK: - WelcomeElement
struct BookMC: Codable,Equatable {
    var id: Int?
    var title, author, description: String?
    var cover: String?
    var publicationDate: String?
    
    static func ==(lhs: BookMC, rhs: BookMC) -> Bool {
        return lhs.id == rhs.id &&
        lhs.title == rhs.title &&
        lhs.author == rhs.author &&
        lhs.description == rhs.description &&
        lhs.cover == rhs.cover &&
        lhs.publicationDate == rhs.publicationDate
    }
}


extension BookMC {
    init(book: Books) {
        self.id = Int(book.id)
        self.title = book.title
        self.author = book.author
        self.description = book.bookDescription
        self.cover = book.cover
        self.publicationDate = book.publicationDate
    }
}


