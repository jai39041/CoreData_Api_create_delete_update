//
//  BookListVC.swift
//  UplerAssignment
//
//  Created by jai prakash on 15/08/24.
//

import UIKit
import SDWebImage

class BookListVC : UIViewController{
    
    @IBOutlet weak var tableView: UITableView!
    var selectedId: Int?
    private var viewModel = BookViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        let nib = UINib(nibName: "BookTVC", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "BookTVC")
        
        initViewModel()
        observeEvent()
    }
    
    override func viewWillAppear(_ animated: Bool) {
       super.viewWillAppear(animated)
        viewModel.fetchBooks()
    }
    
    func initViewModel() {
        viewModel.fetchBooks()
        
        
        
    }
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self else { return }

            switch event {
            case .loading:
                print("Product loading....")
            case .stopLoading:
                print("Stop loading...")
            case .dataLoaded:
                print("Data loaded...")
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .error(let error):
                    print(error!)
            }
        }
    }
    
    
    @IBAction func addBookBtn(_ sender: Any) {
        let vc = ViewControllerAccessors.addBookVC
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
        
    }
    
    
}


extension BookListVC : UITableViewDelegate , UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.bookList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BookTVC", for: indexPath) as! BookTVC
        
        let dataAtIndex = viewModel.bookList[indexPath.row]

        cell.titleLbl.text = dataAtIndex.title
        cell.authorLbl.text = dataAtIndex.author
        cell.descriptionLbl.text = dataAtIndex.description
        cell.publicationDateLbl.text = convertDateString(dateString: dataAtIndex.publicationDate ?? "")
        let url = URL(string: dataAtIndex.cover ?? "")
        cell.coverPic.sd_setImage(with: url, placeholderImage: UIImage(named: "coverImage"))

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dataAtIndex = viewModel.bookList[indexPath.row]
        let vc = ViewControllerAccessors.bookDetailsVC
        vc.selectedId = dataAtIndex.id
        navigationController?.pushViewController(vc, animated: true)
      
        
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            DataHelper.shared.deleteBook(at: indexPath.row)
            viewModel.bookList.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    
    
    
    
}

