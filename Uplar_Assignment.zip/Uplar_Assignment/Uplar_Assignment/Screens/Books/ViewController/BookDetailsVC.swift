//
//  BookDetailsVC.swift
//  UplerAssignment
//
//  Created by jai prakash on 14/08/24.
//

import Foundation
import UIKit


class BookDetailsVC: UIViewController{
    
    var selectedId: Int?
    private var viewModel = BookViewModel()
    
    
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var coverImage: UIImageView!
    
    @IBOutlet weak var booknameLbl: UILabel!
    
    @IBOutlet weak var authorLbl: UILabel!
    
    @IBOutlet weak var descriptionLbl: UILabel!
    
    @IBOutlet weak var publicationDateLbl: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initViewModel()
        observeEvent()
    }
    
    func initViewModel() {
        viewModel.fetchBooksDetails(with: selectedId ?? 1)
    }
    
    func observeEvent() {
        viewModel.eventHandler = { [weak self] event in
            guard let self else { return }

            switch event {
            case .loading:
                print("Book loading....")
            CustomActivityIndicator().showActivityIndicator(view: self.view)
            case .stopLoading:
                print("Stop loading...")
            CustomActivityIndicator().hideActivityIndicator(view: self.view)
            case .dataLoaded:
                print("Data loaded...")
                DispatchQueue.main.async {
                    self.setData()
                }
                    
            case .error(let error):
                    print(error!)

            }
        }
    }

    
    func setData(){
        let data = viewModel.bookDetails
        titleLbl.text = data.title
        booknameLbl.text = data.author
        authorLbl.text = data.title
        descriptionLbl.text = data.description
        publicationDateLbl.text = convertDateString(dateString: data.publicationDate ?? "")
        
        let url = URL(string: data.cover ?? "")
        coverImage.sd_setImage(with: url, placeholderImage: UIImage(named: "coverImage"))
        
     
    }
    
    
    
    
    
    
}
