//
//  AddBookVC.swift
//  Uplar_Assignment
//
//  Created by jai prakash on 16/08/24.
//

import Foundation
import UIKit



class AddBookVC : UIViewController, UITextFieldDelegate{
    
    @IBOutlet weak var txtTitle: UITextField!
    
    @IBOutlet weak var bookImage: UIImageView!
    @IBOutlet weak var txtAuthor: UITextField!
    
    @IBOutlet weak var txtDescription: UITextField!
    
    @IBOutlet weak var txtPublicationDate: UITextField!
    
    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        return formatter
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        txtPublicationDate.delegate = self
        
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        datePicker.addTarget(self, action: #selector(dateChanged(_:)), for: .valueChanged)
        
        txtPublicationDate.inputView = datePicker
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(donePressed))
        toolbar.setItems([doneButton], animated: true)
        
        txtPublicationDate.inputAccessoryView = toolbar
        
        
    }
    
    @objc func dateChanged(_ sender: UIDatePicker) {
        txtPublicationDate.text = dateFormatter.string(from: sender.date)
    }
    
    @objc func donePressed() {
        view.endEditing(true)
    }
 
    
    
    @IBAction func saveBookBtn(_ sender: Any) {
        guard let title = txtTitle.text, !title.isEmpty,
              let author = txtAuthor.text, !author.isEmpty,
              let description = txtDescription.text, !description.isEmpty,
              let publicationDate = txtPublicationDate.text, !publicationDate.isEmpty else {
            print("Please fill in all fields")
            return
        }
        DataHelper.shared.saveBook(
            title: title,
            author: author,
            description: description,
            publicationDate: convertDateFormat(inputDateString: publicationDate)!,
            coverImage: bookImage.image
        )}
    
    
    @IBAction func cancelBtn(_ sender: Any) {
        dismiss(animated: true)
    }
    
}
