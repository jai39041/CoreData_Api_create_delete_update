//
//  BookTVC.swift
//  UplerAssignment
//
//  Created by jai prakash on 13/08/24.
//

import UIKit

class BookTVC: UITableViewCell {
    
    
    @IBOutlet weak var coverPic: UIImageView!
    
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var authorLbl: UILabel!
    
    @IBOutlet weak var descriptionLbl: UILabel!
    
    @IBOutlet weak var publicationDateLbl: UILabel!
    
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
