//
//  BookViewModel.swift
//  UplerAssignment
//
//  Created by jai prakash on 15/08/24.
//

import Foundation


final class BookViewModel {

    var bookList: [BookMC] = []
    var bookDetails : BookMC = BookMC()
    var eventHandler: ((_ event: Event) -> Void)? // Data Binding Closure

    func fetchBooks() {
        self.eventHandler?(.loading)
        APIManager.shared.request(
            modelType: [BookMC].self,
            type: BookEndPoint.books) { response in
            
            self.eventHandler?(.stopLoading)
            
            switch response {
            case .success(let fetchedBooks):
                let existingBooks = DataHelper.shared.fetchBooks().map { BookMC(book: $0) }
                
                let newBooks = fetchedBooks.filter { fetchedBook in
                    !existingBooks.contains { $0.id == fetchedBook.id }
                }
                
                let updatedBooks = fetchedBooks.filter { fetchedBook in
                    existingBooks.contains { $0.id == fetchedBook.id && $0 != fetchedBook }
                }
                
                newBooks.forEach { book in
                    DataHelper.shared.saveBook(book: book)
                }
                
                updatedBooks.forEach { book in
                    DataHelper.shared.updateBook(book: book)
                }
                
                self.bookList = DataHelper.shared.fetchBooks().map { BookMC(book: $0) }
                
                self.eventHandler?(.dataLoaded)
                
            case .failure(let error):
                print("Network error: \(error.localizedDescription)")
                
                self.bookList = DataHelper.shared.fetchBooks().map { BookMC(book: $0) }
                self.eventHandler?(.dataLoaded)
            }
        }
        
        self.bookList = DataHelper.shared.fetchBooks().map { BookMC(book: $0) }
        self.eventHandler?(.dataLoaded)
    }

    
    func fetchBooksDetails(with id: Int) {
        self.eventHandler?(.loading)
        let endpoint = BookEndPoint.bookDetails(id: id)
        APIManager.shared.request(
            modelType: BookMC.self,
            type: endpoint) { response in
                self.eventHandler?(.stopLoading)
                switch response {
                case .success(let books):
                    self.bookDetails = books
                    self.eventHandler?(.dataLoaded)
                case .failure(let error):
                    self.eventHandler?(.error(error))
                }
            }
    }




}

extension BookViewModel {

    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
    }

}
