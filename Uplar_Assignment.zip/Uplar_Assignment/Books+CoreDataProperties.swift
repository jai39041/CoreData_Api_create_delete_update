//
//  Books+CoreDataProperties.swift
//  
//
//  Created by jai prakash on 16/08/24.
//
//

import Foundation
import CoreData


extension Books {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Books> {
        return NSFetchRequest<Books>(entityName: "Books")
    }

    @NSManaged public var author: String?
    @NSManaged public var bookDescription: String?
    @NSManaged public var cover: String?
    @NSManaged public var id: Int64
    @NSManaged public var publicationDate: String?
    @NSManaged public var title: String?

}
